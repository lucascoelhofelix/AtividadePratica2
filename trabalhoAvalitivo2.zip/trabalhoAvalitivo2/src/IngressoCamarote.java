public class IngressoCamarote extends Ingresso {

    private String openbar = "liberado openbar";

    public IngressoCamarote(String nome, int cpf, int id, String openbar) {
        super(nome, cpf, id);
        this.openbar = openbar;
    }

    public String getOponbar() {
        return openbar;
    }
    
       @Override
       public String toString() {
           return super.toString() + openbar;
       }
}
