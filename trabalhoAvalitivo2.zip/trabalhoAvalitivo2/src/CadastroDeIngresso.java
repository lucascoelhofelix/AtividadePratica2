import java.util.ArrayList;
import java.util.List;

public class CadastroDeIngresso {
    
    private static List<Ingresso> listaIngressos = new ArrayList<>();

    public static void cadastrar(Ingresso ing){
        listaIngressos.add(ing);
    }

    public static List<Ingresso> getListaIngressos(){
        return listaIngressos;
    }

    public static List<Ingresso> getIngressosVip() {
        List<Ingresso> tempList = new ArrayList<>();

        for(Ingresso tempFunc: listaIngressos) {
            if (tempFunc instanceof IngressoVip) {
                tempList.add(tempFunc);
            }
        }

        return tempList;
    }

    public static boolean excluir(int id) {

        for (Ingresso tempFuncionario : listaIngressos){
            if (tempFuncionario.getId() == id) {
                listaIngressos.remove(tempFuncionario);
                return true;
            }
        }

        return false;

    }

}
