public class Ingresso {

    private String nome;
    private int cpf;
    private int id;

    public Ingresso(String nome, int cpf, int id) {
        this.nome = nome;
        this.cpf = cpf;
        this.id = id;

        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "\nnome" + nome + "\ncpf" + cpf + "\nID" + id;
        
    }
    
}
