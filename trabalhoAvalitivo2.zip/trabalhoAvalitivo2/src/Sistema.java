public class Sistema {

    private static void exibirMenu() {

        System.out.println("\nCADASTRO DE INGRESSO");
        System.out.println("1) Cadastrar IngressoVip");
        System.out.println("2) Cadastrar Camarote");
        System.out.println("3) LISTAR DJs");
        System.out.println("4) Listar todos os Ingressos");
        System.out.println("5) Listar todos os IngressosVip");
        System.out.println("6) Listar todos os Camarotes");
        System.out.println("7) Listar todos os Djs");
        System.out.println("8) Remover Ingresso");
        System.out.println("0) Sair");
        System.out.print("Informe uma opção:");

    }

    private static void verificarOpcao(int op) {

        String nome;
        int cpf;
        int id;

        switch (op) {
            case 1:

                System.out.println("\nCADASTRO DE INGRESSO VIP:");
                // leitura dos dados
                System.out.print("Nome: ");
                nome = Console.lerString();
                System.out.print("CPF: ");
                cpf = Console.lerInt();
                System.out.println("ID: ");
                id = Console.lerInt();
                System.out.print("codigo do ingresso vip: ");
                String pista = Console.lerString();

                IngressoVip IngressosVip = new IngressoVip(nome, cpf, id, pista);
                
                CadastroDeIngresso.cadastrar(IngressosVip);
                System.out.println("\nIngresso Vip cadastrado com sucesso!");

                break;

            case 2:

                System.out.println("\nCADASTRO DE INGRESSO VIP:");
                System.out.print("Nome: ");
               nome = Console.lerString();
                System.out.print("CPF: ");
                cpf = Console.lerInt();
                System.out.println("ID: ");
                id = Console.lerInt();
                System.out.print("codigo do Openbar ");
                String Openbar  = Console.lerString();

                IngressoCamarote ingressoCamarote = new IngressoCamarote(nome, cpf, id, Openbar);
            
                CadastroDeIngresso.cadastrar(ingressoCamarote);
                System.out.println("\nIngresso camarote cadastrado com sucesso!");

            case 3:

                System.out.println("\nCADASTRO DE DJ:");
                System.out.print("Nome: ");
                nome = Console.lerString();
                System.out.print("CPF: ");
                cpf = Console.lerInt();
                System.out.println("ID: ");
                id = Console.lerInt();
                System.out.print("Acesso a area restrita ");
                String acessoAreaRestrita = Console.lerString();

                Dj dj = new Dj(nome, cpf, id, acessoAreaRestrita);
            
                CadastroDeIngresso.cadastrar(dj);
                System.out.println("\nDJ cadastrado com sucesso!");

            case 4:

                if (CadastroDeIngresso.getIngressosVip().size() == 0) {
                    System.out.println("Não há Ingresso vip cadastrados...");
                    break;
                }
        
                System.out.println("\nINGRESSOS CADASTRADOS:");
                for (Ingresso tempIngresso : CadastroDeIngresso.getListaIngressos()) {
                    System.out.println(tempIngresso);
                }

                break;

            case 5:

                System.out.println("\nVIPs CADASTRADOS:");

                for (Ingresso tempIngresso : CadastroDeIngresso.getIngressosVip()) {
                    System.out.println(tempIngresso);
                }


                break;

            case 6:

                System.out.println("\nPROGRAMADORES CADASTRADOS:");
                for (Ingresso tempIngresso : CadastroDeIngresso.getListaIngressos()) {
                
                    if(tempIngresso instanceof IngressoCamarote) {
                        System.out.println(tempIngresso);
                    }
                }
                break;
            case 7: 

                 System.out.println("\nDJs CADASTRADOS:");
                 for (Ingresso tempIngresso : CadastroDeIngresso.getListaIngressos()) {
                
                    if(tempIngresso instanceof Dj) {
                        System.out.println(tempIngresso);
                    }
                }
                break;
            case 8: 

                System.out.println("\nREMOVER FUNCIONÁRIO");
                System.out.print("Informe a matícula do funcionário: ");
                id = Console.lerInt();

                if (CadastroDeIngresso.excluir(id)){
                    System.out.println("\nIngresso foi removido com sucesso!");
                 } else {
                    System.out.println("\nIngresso " + id + " não localizado no cadastro");
                }

                break;

            case 0:

                System.out.println("\nO Sistema foi finalizado...");
                break;

            default:
                System.out.println("\nOpção inválida. Digite novamente.");
                break;
        }

        System.out.println();

    }

    public static void executar() {

        int op;

        do {

            exibirMenu();
            op = Console.lerInt();
            verificarOpcao(op);

        } while (op != 0);

    }

}
