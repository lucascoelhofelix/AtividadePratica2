public class IngressoVip extends Ingresso {

    private String pista = "pista Vip" ;

    public IngressoVip(String nome, int cpf, int id, String pista) {
        super(nome, cpf, id);
    }    
    
    public String getPista() {
        return pista;
    }
    
    @Override
    public String toString() {
        return super.toString() + pista;
    }

}
