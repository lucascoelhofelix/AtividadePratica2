public class Dj extends Ingresso{

    private String acessoAreaRestrita = "area restrita autorizada";

    public Dj(String nome, int cpf, int id, String acessoAreaRestrita) {
        super(nome, cpf, id);
        this.acessoAreaRestrita = acessoAreaRestrita;
    }

    public String getAcessoAreaRestrita() {
        return acessoAreaRestrita;
    }

    @Override
    public String toString() {
        return super.toString() + acessoAreaRestrita;
    }
}
